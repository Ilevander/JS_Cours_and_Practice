
window.onload = function () {

	// affiche la source de l'image cliquée dans l'image
	// d'id "realize"
	function show() {
		
	}

	// ici, il faut relier la fonction "show" à l'évènement "onmouseover"
	// sur toutes les images ayant la classe "miniature"
	

};
