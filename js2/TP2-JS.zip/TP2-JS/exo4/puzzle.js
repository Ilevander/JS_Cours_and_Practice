
window.onload = function () {

	// pour distinguer les premiers clics
	// des seconds clics
	let first_click = true;

	// pour stocker la première image cliquée
	let first_image;

	// si "not_finished" est vrai, alors
	// il reste des images à permuter
	let not_finished = true;

	// traîte le clic sur une image
	function click_on() {
		
	}

	// teste si le puzzle est terminé
	function is_finished() {
		
	}

	// ici, il faut relier la fonction "clic_on" à l'évènement "onclick"
	// sur toutes les images contenues dans l'élément d'id "puzzle"

};
