
window.onload = function () {

	// affiche le nombre "t" dans le span "spanElt"
	// "t" a au plus deux chiffres
	function afficher(t, span) {
		
	}

	// met à jour les images de l'horloge
	// à chaque seconde
	function tictac() {
		
	}

	// ici, il faut lancer l'horloge
	
};